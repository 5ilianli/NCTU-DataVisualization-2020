//
//  main.cpp
//  name
//
//  Created by ㄚ ㄏㄨㄣ on 2019/11/22.
//  Copyright © 2019 ㄚ ㄏㄨㄣ. All rights reserved.
//

#include <iostream>
#include <cstdio>
#include <fstream>
#include <cstring>
#include <map>
using namespace std;

int main(void) {
    map<string,string> name;
    string str;
    string str2;
    int i=0;

    while (i<154) {
        getline(cin,str);
        getline(cin,str2);
        name.insert(pair<string,string>(str,str2));
        i++;
        cout<<str<<" "<<str2<<endl;
    }
    cout<<i<<endl;
    cout<<"$$\n";
    
    //cout<<"%%\n";
    //cin.get();
    //cout<<name["Kenya"]<<endl;

    char str3[60];
    int j=0;


    while (j<156) {
        cin.getline(str3,sizeof(str3),'\n');
        cout<<str3<<" "<<name[str3]<<endl;
        j++;
    }
    
    

    return 0;
}
